(function(){
function toggleMenu(burgerId){
const burger = document.getElementById(burgerId);
if(!burger) return;
burger.addEventListener('click', ()=>{
const nav = document.querySelector('.main-nav');
if(!nav) return;
nav.style.display = (nav.style.display === 'flex') ? 'none' : 'flex';
});
}
toggleMenu('burger');
toggleMenu('burger2');
})();